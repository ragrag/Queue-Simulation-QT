/****************************************************************************
** Meta object code from reading C++ file 'chartwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../chartwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chartwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ChartWindow_t {
    QByteArrayData data[38];
    char stringdata0[870];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ChartWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ChartWindow_t qt_meta_stringdata_ChartWindow = {
    {
QT_MOC_LITERAL(0, 0, 11), // "ChartWindow"
QT_MOC_LITERAL(1, 12, 23), // "on_svcDPieBtn_2_clicked"
QT_MOC_LITERAL(2, 36, 0), // ""
QT_MOC_LITERAL(3, 37, 21), // "on_svcIPieBtn_clicked"
QT_MOC_LITERAL(4, 59, 22), // "on_waitDPieBtn_clicked"
QT_MOC_LITERAL(5, 82, 22), // "on_waitIPieBtn_clicked"
QT_MOC_LITERAL(6, 105, 19), // "on_qlPieBtn_clicked"
QT_MOC_LITERAL(7, 125, 21), // "on_probPieBtn_clicked"
QT_MOC_LITERAL(8, 147, 21), // "on_idlePieBtn_clicked"
QT_MOC_LITERAL(9, 169, 21), // "on_svcIBarBtn_clicked"
QT_MOC_LITERAL(10, 191, 22), // "on_waitDBarBtn_clicked"
QT_MOC_LITERAL(11, 214, 22), // "on_waitIBarBtn_clicked"
QT_MOC_LITERAL(12, 237, 19), // "on_qlBarBtn_clicked"
QT_MOC_LITERAL(13, 257, 21), // "on_probBarBtn_clicked"
QT_MOC_LITERAL(14, 279, 21), // "on_idleBarBtn_clicked"
QT_MOC_LITERAL(15, 301, 22), // "on_interBarBtn_clicked"
QT_MOC_LITERAL(16, 324, 22), // "on_interPieBtn_clicked"
QT_MOC_LITERAL(17, 347, 23), // "on_svcAllBarBtn_clicked"
QT_MOC_LITERAL(18, 371, 23), // "on_svcAllPieBtn_clicked"
QT_MOC_LITERAL(19, 395, 23), // "on_svcDBarBtn_2_clicked"
QT_MOC_LITERAL(20, 419, 28), // "on_avgSvcAllHist_Btn_clicked"
QT_MOC_LITERAL(21, 448, 27), // "on_avgInterHist_Btn_clicked"
QT_MOC_LITERAL(22, 476, 26), // "on_avgSvcDHist_btn_clicked"
QT_MOC_LITERAL(23, 503, 26), // "on_avgSvcIHist_Btn_clicked"
QT_MOC_LITERAL(24, 530, 27), // "on_avgWaitDHist_Btn_clicked"
QT_MOC_LITERAL(25, 558, 23), // "on_avgWaitI_Btn_clicked"
QT_MOC_LITERAL(26, 582, 23), // "on_maxQHist_Btn_clicked"
QT_MOC_LITERAL(27, 606, 25), // "on_probInHist_Btn_clicked"
QT_MOC_LITERAL(28, 632, 23), // "on_idleHist_Btn_clicked"
QT_MOC_LITERAL(29, 656, 25), // "on_svcAllLine_Btn_clicked"
QT_MOC_LITERAL(30, 682, 24), // "on_interLine_Btn_clicked"
QT_MOC_LITERAL(31, 707, 24), // "on_svcDLineBtn_2_clicked"
QT_MOC_LITERAL(32, 732, 22), // "on_svcILineBtn_clicked"
QT_MOC_LITERAL(33, 755, 23), // "on_waitDLineBtn_clicked"
QT_MOC_LITERAL(34, 779, 23), // "on_waitILineBtn_clicked"
QT_MOC_LITERAL(35, 803, 20), // "on_qlLineBtn_clicked"
QT_MOC_LITERAL(36, 824, 22), // "on_probLineBtn_clicked"
QT_MOC_LITERAL(37, 847, 22) // "on_idleLineBtn_clicked"

    },
    "ChartWindow\0on_svcDPieBtn_2_clicked\0"
    "\0on_svcIPieBtn_clicked\0on_waitDPieBtn_clicked\0"
    "on_waitIPieBtn_clicked\0on_qlPieBtn_clicked\0"
    "on_probPieBtn_clicked\0on_idlePieBtn_clicked\0"
    "on_svcIBarBtn_clicked\0on_waitDBarBtn_clicked\0"
    "on_waitIBarBtn_clicked\0on_qlBarBtn_clicked\0"
    "on_probBarBtn_clicked\0on_idleBarBtn_clicked\0"
    "on_interBarBtn_clicked\0on_interPieBtn_clicked\0"
    "on_svcAllBarBtn_clicked\0on_svcAllPieBtn_clicked\0"
    "on_svcDBarBtn_2_clicked\0"
    "on_avgSvcAllHist_Btn_clicked\0"
    "on_avgInterHist_Btn_clicked\0"
    "on_avgSvcDHist_btn_clicked\0"
    "on_avgSvcIHist_Btn_clicked\0"
    "on_avgWaitDHist_Btn_clicked\0"
    "on_avgWaitI_Btn_clicked\0on_maxQHist_Btn_clicked\0"
    "on_probInHist_Btn_clicked\0"
    "on_idleHist_Btn_clicked\0"
    "on_svcAllLine_Btn_clicked\0"
    "on_interLine_Btn_clicked\0"
    "on_svcDLineBtn_2_clicked\0"
    "on_svcILineBtn_clicked\0on_waitDLineBtn_clicked\0"
    "on_waitILineBtn_clicked\0on_qlLineBtn_clicked\0"
    "on_probLineBtn_clicked\0on_idleLineBtn_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ChartWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      36,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  194,    2, 0x08 /* Private */,
       3,    0,  195,    2, 0x08 /* Private */,
       4,    0,  196,    2, 0x08 /* Private */,
       5,    0,  197,    2, 0x08 /* Private */,
       6,    0,  198,    2, 0x08 /* Private */,
       7,    0,  199,    2, 0x08 /* Private */,
       8,    0,  200,    2, 0x08 /* Private */,
       9,    0,  201,    2, 0x08 /* Private */,
      10,    0,  202,    2, 0x08 /* Private */,
      11,    0,  203,    2, 0x08 /* Private */,
      12,    0,  204,    2, 0x08 /* Private */,
      13,    0,  205,    2, 0x08 /* Private */,
      14,    0,  206,    2, 0x08 /* Private */,
      15,    0,  207,    2, 0x08 /* Private */,
      16,    0,  208,    2, 0x08 /* Private */,
      17,    0,  209,    2, 0x08 /* Private */,
      18,    0,  210,    2, 0x08 /* Private */,
      19,    0,  211,    2, 0x08 /* Private */,
      20,    0,  212,    2, 0x08 /* Private */,
      21,    0,  213,    2, 0x08 /* Private */,
      22,    0,  214,    2, 0x08 /* Private */,
      23,    0,  215,    2, 0x08 /* Private */,
      24,    0,  216,    2, 0x08 /* Private */,
      25,    0,  217,    2, 0x08 /* Private */,
      26,    0,  218,    2, 0x08 /* Private */,
      27,    0,  219,    2, 0x08 /* Private */,
      28,    0,  220,    2, 0x08 /* Private */,
      29,    0,  221,    2, 0x08 /* Private */,
      30,    0,  222,    2, 0x08 /* Private */,
      31,    0,  223,    2, 0x08 /* Private */,
      32,    0,  224,    2, 0x08 /* Private */,
      33,    0,  225,    2, 0x08 /* Private */,
      34,    0,  226,    2, 0x08 /* Private */,
      35,    0,  227,    2, 0x08 /* Private */,
      36,    0,  228,    2, 0x08 /* Private */,
      37,    0,  229,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ChartWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ChartWindow *_t = static_cast<ChartWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_svcDPieBtn_2_clicked(); break;
        case 1: _t->on_svcIPieBtn_clicked(); break;
        case 2: _t->on_waitDPieBtn_clicked(); break;
        case 3: _t->on_waitIPieBtn_clicked(); break;
        case 4: _t->on_qlPieBtn_clicked(); break;
        case 5: _t->on_probPieBtn_clicked(); break;
        case 6: _t->on_idlePieBtn_clicked(); break;
        case 7: _t->on_svcIBarBtn_clicked(); break;
        case 8: _t->on_waitDBarBtn_clicked(); break;
        case 9: _t->on_waitIBarBtn_clicked(); break;
        case 10: _t->on_qlBarBtn_clicked(); break;
        case 11: _t->on_probBarBtn_clicked(); break;
        case 12: _t->on_idleBarBtn_clicked(); break;
        case 13: _t->on_interBarBtn_clicked(); break;
        case 14: _t->on_interPieBtn_clicked(); break;
        case 15: _t->on_svcAllBarBtn_clicked(); break;
        case 16: _t->on_svcAllPieBtn_clicked(); break;
        case 17: _t->on_svcDBarBtn_2_clicked(); break;
        case 18: _t->on_avgSvcAllHist_Btn_clicked(); break;
        case 19: _t->on_avgInterHist_Btn_clicked(); break;
        case 20: _t->on_avgSvcDHist_btn_clicked(); break;
        case 21: _t->on_avgSvcIHist_Btn_clicked(); break;
        case 22: _t->on_avgWaitDHist_Btn_clicked(); break;
        case 23: _t->on_avgWaitI_Btn_clicked(); break;
        case 24: _t->on_maxQHist_Btn_clicked(); break;
        case 25: _t->on_probInHist_Btn_clicked(); break;
        case 26: _t->on_idleHist_Btn_clicked(); break;
        case 27: _t->on_svcAllLine_Btn_clicked(); break;
        case 28: _t->on_interLine_Btn_clicked(); break;
        case 29: _t->on_svcDLineBtn_2_clicked(); break;
        case 30: _t->on_svcILineBtn_clicked(); break;
        case 31: _t->on_waitDLineBtn_clicked(); break;
        case 32: _t->on_waitILineBtn_clicked(); break;
        case 33: _t->on_qlLineBtn_clicked(); break;
        case 34: _t->on_probLineBtn_clicked(); break;
        case 35: _t->on_idleLineBtn_clicked(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject ChartWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_ChartWindow.data,
      qt_meta_data_ChartWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *ChartWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ChartWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ChartWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int ChartWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 36)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 36;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 36)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 36;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
